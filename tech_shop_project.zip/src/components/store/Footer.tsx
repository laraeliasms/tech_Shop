import { Zap } from "lucide-react";

const Footer = () => (
  <footer className="mt-20 border-t border-purple-900/40 bg-slate-950">
    <div className="mx-auto max-w-7xl px-4 md:px-8 py-10 grid gap-6 md:grid-cols-3">
      <div>
        <div className="flex items-center gap-2 mb-3">
          <Zap className="w-5 h-5 text-cyan-300" />
          <span className="font-bold text-slate-100">TechStore</span>
        </div>
        <p className="text-sm text-slate-400">Sua loja gamer e tecnológica com os melhores produtos do mercado.</p>
      </div>
      <div>
        <h4 className="font-semibold text-slate-200 mb-3">Categorias</h4>
        <ul className="space-y-1 text-sm text-slate-400">
          <li>Notebooks Gamer</li><li>PCs Gamer</li><li>Periféricos</li><li>Acessórios</li>
        </ul>
      </div>
      <div>
        <h4 className="font-semibold text-slate-200 mb-3">Contato</h4>
        <p className="text-sm text-slate-400">contato@techstore.com</p>
        <p className="text-sm text-slate-400">(11) 99999-0000</p>
      </div>
    </div>
    <div className="border-t border-purple-900/40 py-4 text-center text-xs text-slate-500">
      © {new Date().getFullYear()} TechStore — Projeto acadêmico React.
    </div>
  </footer>
);

export default Footer;
