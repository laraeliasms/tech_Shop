import { Link, NavLink } from "react-router-dom";
import { ShoppingCart, Zap } from "lucide-react";
import { useCart } from "@/context/CartContext";

const Header = () => {
  const { totalItems } = useCart();
  const linkCls = ({ isActive }: { isActive: boolean }) =>
    `text-sm font-medium transition-colors hover:text-neon ${isActive ? "text-neon" : "text-slate-300"}`;

  return (
    <header className="sticky top-0 z-50 backdrop-blur-md bg-slate-950/80 border-b border-purple-900/40">
      <div className="mx-auto max-w-7xl px-4 md:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-cyan-400 grid place-items-center shadow-[0_0_20px_rgba(168,85,247,0.5)]">
            <Zap className="w-5 h-5 text-white" />
          </div>
          <span className="text-lg font-bold bg-gradient-to-r from-purple-400 to-cyan-300 bg-clip-text text-transparent">
            TechStore
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <NavLink to="/" end className={linkCls}>Início</NavLink>
          <NavLink to="/products" className={linkCls}>Produtos</NavLink>
          <NavLink to="/cart" className={linkCls}>Carrinho</NavLink>
        </nav>

        <Link
          to="/cart"
          className="relative inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-purple-600/20 border border-purple-500/40 hover:bg-purple-600/30 hover:border-purple-400 transition-all hover:shadow-[0_0_15px_rgba(168,85,247,0.4)]"
        >
          <ShoppingCart className="w-5 h-5 text-cyan-300" />
          <span className="hidden sm:inline text-sm font-medium text-slate-100">Carrinho</span>
          {totalItems > 0 && (
            <span className="absolute -top-2 -right-2 min-w-[22px] h-[22px] px-1 grid place-items-center text-xs font-bold rounded-full bg-cyan-400 text-slate-950 shadow-[0_0_10px_rgba(34,211,238,0.8)]">
              {totalItems}
            </span>
          )}
        </Link>
      </div>
    </header>
  );
};

export default Header;
