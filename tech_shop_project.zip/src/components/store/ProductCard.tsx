import { Product } from "@/data/products";
import { useCart, formatBRL } from "@/context/CartContext";
import { ShoppingCart } from "lucide-react";

const ProductCard = ({ product }: { product: Product }) => {
  const { add } = useCart();
  const Icon = product.icon;

  return (
    <div className="group relative rounded-2xl bg-slate-900/60 border border-purple-900/40 p-5 flex flex-col gap-4 transition-all hover:border-cyan-400/60 hover:shadow-[0_0_25px_rgba(34,211,238,0.2)] hover:-translate-y-1">
      <div className="aspect-square rounded-xl bg-gradient-to-br from-purple-900/40 to-slate-800 grid place-items-center border border-purple-900/30">
        <Icon className="w-20 h-20 text-cyan-300 group-hover:scale-110 transition-transform" strokeWidth={1.2} />
      </div>
      <div className="flex-1 flex flex-col gap-2">
        <span className="text-xs uppercase tracking-wider text-purple-400 font-semibold">{product.category}</span>
        <h3 className="font-bold text-slate-100 leading-tight">{product.name}</h3>
        <p className="text-sm text-slate-400 line-clamp-2">{product.description}</p>
      </div>
      <div className="flex items-end justify-between gap-3">
        <span className="text-xl font-extrabold bg-gradient-to-r from-cyan-300 to-purple-400 bg-clip-text text-transparent">
          {formatBRL(product.price)}
        </span>
        <button
          onClick={() => add(product)}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-sm font-semibold shadow-lg hover:shadow-[0_0_20px_rgba(168,85,247,0.5)] active:scale-95 transition-all"
        >
          <ShoppingCart className="w-4 h-4" />
          Adicionar
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
