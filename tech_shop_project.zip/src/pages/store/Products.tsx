import { useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Search } from "lucide-react";
import Layout from "@/components/store/Layout";
import ProductCard from "@/components/store/ProductCard";
import { categories, products } from "@/data/products";

const Products = () => {
  const [params] = useSearchParams();
  const [cat, setCat] = useState("Todos");
  const [q, setQ] = useState(params.get("q") ?? "");

  const filtered = useMemo(() => {
    return products.filter((p) => {
      const okCat = cat === "Todos" || p.category === cat;
      const okQ = !q || p.name.toLowerCase().includes(q.toLowerCase()) || p.description.toLowerCase().includes(q.toLowerCase());
      return okCat && okQ;
    });
  }, [cat, q]);

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-10">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-100">Catálogo de Produtos</h1>
        <p className="text-slate-400 mt-1">Encontre o equipamento ideal para você</p>

        <div className="mt-6 flex flex-col md:flex-row gap-3 items-stretch md:items-center">
          <div className="flex items-center gap-2 flex-1 bg-slate-900/70 border border-purple-900/50 rounded-xl px-3 py-2 focus-within:border-cyan-400/60">
            <Search className="w-4 h-4 text-slate-500" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Buscar..."
              className="flex-1 bg-transparent outline-none text-sm text-slate-100 placeholder:text-slate-500"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setCat(c)}
                className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap border transition-all ${
                  cat === c
                    ? "bg-gradient-to-r from-purple-600 to-cyan-500 text-white border-transparent shadow-[0_0_15px_rgba(168,85,247,0.4)]"
                    : "bg-slate-900/60 text-slate-300 border-purple-900/40 hover:border-cyan-400/50"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {filtered.length === 0 ? (
          <p className="text-center text-slate-400 py-20">Nenhum produto encontrado.</p>
        ) : (
          <div className="mt-8 grid gap-5 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </section>
    </Layout>
  );
};

export default Products;
