import { Link, useNavigate } from "react-router-dom";
import { Minus, Plus, Trash2, ArrowRight, ShoppingBag, Tag } from "lucide-react";
import Layout from "@/components/store/Layout";
import { useCart, formatBRL } from "@/context/CartContext";
import { useState } from "react";
import { toast } from "sonner";

const Cart = () => {
  const { items, updateQty, remove, subtotal, totalItems, clear } = useCart();
  const navigate = useNavigate();
  const [coupon, setCoupon] = useState("");
  const [discount, setDiscount] = useState(0);

  const applyCoupon = () => {
    if (coupon.trim().toUpperCase() === "TECH10") {
      setDiscount(0.1);
      toast.success("Cupom TECH10 aplicado: 10% OFF");
    } else {
      setDiscount(0);
      toast.error("Cupom inválido");
    }
  };

  const total = subtotal * (1 - discount);

  if (items.length === 0) {
    return (
      <Layout>
        <section className="mx-auto max-w-3xl px-4 md:px-8 py-24 text-center">
          <ShoppingBag className="w-16 h-16 mx-auto text-purple-400 mb-4" />
          <h1 className="text-3xl font-bold text-slate-100">Seu carrinho está vazio</h1>
          <p className="text-slate-400 mt-2">Adicione produtos para continuar</p>
          <Link to="/products" className="inline-flex mt-6 items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-semibold">
            Ver produtos <ArrowRight className="w-4 h-4" />
          </Link>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-10">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-100">Meu Carrinho</h1>
        <p className="text-slate-400 mt-1">{totalItems} {totalItems === 1 ? "item" : "itens"}</p>

        <div className="mt-8 grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-3">
            {items.map((it) => {
              const Icon = it.icon;
              return (
                <div key={it.id} className="flex gap-4 p-4 rounded-2xl bg-slate-900/60 border border-purple-900/40">
                  <div className="w-20 h-20 rounded-xl bg-gradient-to-br from-purple-900/40 to-slate-800 grid place-items-center shrink-0 border border-purple-900/30">
                    <Icon className="w-10 h-10 text-cyan-300" strokeWidth={1.2} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs uppercase text-purple-400 font-semibold">{it.category}</p>
                    <h3 className="font-semibold text-slate-100 truncate">{it.name}</h3>
                    <p className="text-sm text-cyan-300 font-bold mt-1">{formatBRL(it.price)}</p>
                  </div>
                  <div className="flex flex-col items-end justify-between">
                    <button onClick={() => remove(it.id)} className="text-slate-500 hover:text-red-400 transition">
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div className="flex items-center gap-1 bg-slate-950 border border-purple-900/40 rounded-lg">
                      <button onClick={() => updateQty(it.id, it.quantity - 1)} className="p-1.5 hover:text-cyan-300"><Minus className="w-3.5 h-3.5" /></button>
                      <span className="w-6 text-center text-sm font-semibold">{it.quantity}</span>
                      <button onClick={() => updateQty(it.id, it.quantity + 1)} className="p-1.5 hover:text-cyan-300"><Plus className="w-3.5 h-3.5" /></button>
                    </div>
                  </div>
                </div>
              );
            })}
            <button onClick={clear} className="text-sm text-slate-500 hover:text-red-400 transition">Limpar carrinho</button>
          </div>

          <aside className="rounded-2xl bg-slate-900/60 border border-purple-900/40 p-6 h-fit sticky top-20">
            <h3 className="font-bold text-slate-100 mb-4">Resumo do pedido</h3>

            <div className="flex gap-2 mb-4">
              <div className="flex items-center gap-2 flex-1 bg-slate-950 border border-purple-900/40 rounded-lg px-3">
                <Tag className="w-4 h-4 text-purple-400" />
                <input
                  value={coupon}
                  onChange={(e) => setCoupon(e.target.value)}
                  placeholder="Cupom (TECH10)"
                  className="flex-1 bg-transparent outline-none py-2 text-sm placeholder:text-slate-500"
                />
              </div>
              <button onClick={applyCoupon} className="px-3 py-2 rounded-lg border border-purple-500/50 text-sm font-semibold hover:bg-purple-600/10">
                Aplicar
              </button>
            </div>

            <div className="space-y-2 text-sm border-t border-purple-900/40 pt-4">
              <div className="flex justify-between text-slate-400"><span>Subtotal</span><span>{formatBRL(subtotal)}</span></div>
              {discount > 0 && (
                <div className="flex justify-between text-cyan-300"><span>Desconto</span><span>-{formatBRL(subtotal * discount)}</span></div>
              )}
              <div className="flex justify-between text-slate-400"><span>Frete</span><span className="text-cyan-300">Grátis</span></div>
              <div className="flex justify-between text-lg font-bold text-slate-100 pt-2 border-t border-purple-900/40">
                <span>Total</span><span>{formatBRL(total)}</span>
              </div>
            </div>

            <button
              onClick={() => navigate("/checkout", { state: { discount } })}
              className="mt-5 w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-semibold shadow-lg hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] active:scale-95 transition-all"
            >
              Avançar para pagamento <ArrowRight className="w-4 h-4" />
            </button>
          </aside>
        </div>
      </section>
    </Layout>
  );
};

export default Cart;
