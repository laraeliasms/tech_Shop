import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { CreditCard, Loader2, User } from "lucide-react";
import Layout from "@/components/store/Layout";
import { useCart, formatBRL } from "@/context/CartContext";
import { toast } from "sonner";

type FormState = {
  name: string; cpf: string; email: string; phone: string;
  address: string; city: string; state: string; zip: string;
  cardName: string; cardNumber: string; cardExp: string; cardCvv: string;
};

const onlyDigits = (s: string) => s.replace(/\D/g, "");
const maskCPF = (s: string) => onlyDigits(s).slice(0, 11).replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d)/, "$1.$2").replace(/(\d{3})(\d{1,2})$/, "$1-$2");
const maskPhone = (s: string) => onlyDigits(s).slice(0, 11).replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
const maskZip = (s: string) => onlyDigits(s).slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");
const maskCard = (s: string) => onlyDigits(s).slice(0, 16).replace(/(\d{4})(?=\d)/g, "$1 ");
const maskExp = (s: string) => onlyDigits(s).slice(0, 4).replace(/(\d{2})(\d)/, "$1/$2");

const Checkout = () => {
  const { items, subtotal, clear } = useCart();
  const nav = useNavigate();
  const loc = useLocation() as { state?: { discount?: number } };
  const discount = loc.state?.discount ?? 0;
  const total = subtotal * (1 - discount);

  const [f, setF] = useState<FormState>({
    name: "", cpf: "", email: "", phone: "", address: "", city: "", state: "", zip: "",
    cardName: "", cardNumber: "", cardExp: "", cardCvv: "",
  });
  const [errors, setErrors] = useState<Partial<Record<keyof FormState, string>>>({});
  const [loading, setLoading] = useState(false);

  const set = (k: keyof FormState, v: string) => setF((p) => ({ ...p, [k]: v }));

  const validate = () => {
    const e: Partial<Record<keyof FormState, string>> = {};
    if (f.name.trim().length < 3) e.name = "Nome muito curto";
    if (onlyDigits(f.cpf).length !== 11) e.cpf = "CPF inválido";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.email)) e.email = "E-mail inválido";
    if (onlyDigits(f.phone).length < 10) e.phone = "Telefone inválido";
    if (!f.address.trim()) e.address = "Obrigatório";
    if (!f.city.trim()) e.city = "Obrigatório";
    if (f.state.trim().length !== 2) e.state = "UF (2 letras)";
    if (onlyDigits(f.zip).length !== 8) e.zip = "CEP inválido";
    if (!f.cardName.trim()) e.cardName = "Obrigatório";
    if (onlyDigits(f.cardNumber).length !== 16) e.cardNumber = "Cartão inválido";
    if (onlyDigits(f.cardExp).length !== 4) e.cardExp = "MM/AA";
    if (onlyDigits(f.cardCvv).length < 3) e.cardCvv = "CVV inválido";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) { toast.error("Carrinho vazio"); return; }
    if (!validate()) { toast.error("Verifique os campos do formulário"); return; }
    setLoading(true);
    setTimeout(() => {
      const order = {
        id: Math.floor(100000 + Math.random() * 900000),
        items, total, customer: f.name, email: f.email,
      };
      clear();
      nav("/success", { state: order });
    }, 1800);
  };

  const field = (
    k: keyof FormState,
    label: string,
    opts: { placeholder?: string; onChange?: (v: string) => void; span?: string } = {}
  ) => (
    <div className={opts.span}>
      <label className="block text-xs font-semibold text-slate-300 mb-1.5">{label}</label>
      <input
        value={f[k]}
        onChange={(e) => (opts.onChange ? opts.onChange(e.target.value) : set(k, e.target.value))}
        placeholder={opts.placeholder}
        className={`w-full bg-slate-950 border rounded-lg px-3 py-2.5 text-sm outline-none transition ${
          errors[k] ? "border-red-500/60" : "border-purple-900/40 focus:border-cyan-400/60"
        }`}
      />
      {errors[k] && <p className="text-xs text-red-400 mt-1">{errors[k]}</p>}
    </div>
  );

  return (
    <Layout>
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-10">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-100">Finalizar Compra</h1>

        <form onSubmit={submit} className="mt-8 grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-2xl bg-slate-900/60 border border-purple-900/40 p-6">
              <h3 className="font-bold text-slate-100 mb-5 flex items-center gap-2"><User className="w-4 h-4 text-cyan-300" /> Dados Pessoais</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {field("name", "Nome completo", { placeholder: "João da Silva", span: "sm:col-span-2" })}
                {field("cpf", "CPF", { placeholder: "000.000.000-00", onChange: (v) => set("cpf", maskCPF(v)) })}
                {field("phone", "Telefone", { placeholder: "(11) 99999-9999", onChange: (v) => set("phone", maskPhone(v)) })}
                {field("email", "E-mail", { placeholder: "voce@email.com", span: "sm:col-span-2" })}
                {field("address", "Endereço", { placeholder: "Rua, número", span: "sm:col-span-2" })}
                {field("city", "Cidade")}
                {field("state", "Estado (UF)", { placeholder: "SP", onChange: (v) => set("state", v.toUpperCase().slice(0, 2)) })}
                {field("zip", "CEP", { placeholder: "00000-000", onChange: (v) => set("zip", maskZip(v)), span: "sm:col-span-2" })}
              </div>
            </div>

            <div className="rounded-2xl bg-slate-900/60 border border-purple-900/40 p-6">
              <h3 className="font-bold text-slate-100 mb-5 flex items-center gap-2"><CreditCard className="w-4 h-4 text-cyan-300" /> Pagamento</h3>
              <div className="grid sm:grid-cols-2 gap-4">
                {field("cardName", "Nome no cartão", { onChange: (v) => set("cardName", v.toUpperCase()), span: "sm:col-span-2" })}
                {field("cardNumber", "Número do cartão", { placeholder: "0000 0000 0000 0000", onChange: (v) => set("cardNumber", maskCard(v)), span: "sm:col-span-2" })}
                {field("cardExp", "Validade", { placeholder: "MM/AA", onChange: (v) => set("cardExp", maskExp(v)) })}
                {field("cardCvv", "CVV", { placeholder: "123", onChange: (v) => set("cardCvv", onlyDigits(v).slice(0, 4)) })}
              </div>
            </div>
          </div>

          <aside className="rounded-2xl bg-slate-900/60 border border-purple-900/40 p-6 h-fit sticky top-20">
            <h3 className="font-bold text-slate-100 mb-4">Seu pedido</h3>
            <div className="space-y-2 max-h-64 overflow-auto pr-1">
              {items.map((i) => (
                <div key={i.id} className="flex justify-between text-sm">
                  <span className="text-slate-300 truncate pr-2">{i.quantity}x {i.name}</span>
                  <span className="text-slate-400 shrink-0">{formatBRL(i.price * i.quantity)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-purple-900/40 mt-4 pt-4 space-y-1 text-sm">
              <div className="flex justify-between text-slate-400"><span>Subtotal</span><span>{formatBRL(subtotal)}</span></div>
              {discount > 0 && <div className="flex justify-between text-cyan-300"><span>Desconto</span><span>-{formatBRL(subtotal * discount)}</span></div>}
              <div className="flex justify-between text-lg font-bold text-slate-100 pt-2"><span>Total</span><span>{formatBRL(total)}</span></div>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="mt-5 w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-semibold shadow-lg hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] active:scale-95 transition-all disabled:opacity-60"
            >
              {loading ? (<><Loader2 className="w-4 h-4 animate-spin" /> Processando...</>) : "Finalizar Compra"}
            </button>
          </aside>
        </form>
      </section>
    </Layout>
  );
};

export default Checkout;
