import { Link } from "react-router-dom";
import { ArrowRight, Search, Sparkles } from "lucide-react";
import Layout from "@/components/store/Layout";
import ProductCard from "@/components/store/ProductCard";
import { products } from "@/data/products";
import { useState } from "react";

const Home = () => {
  const featured = products.slice(0, 4);
  const [q, setQ] = useState("");

  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden border-b border-purple-900/40">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_30%,rgba(168,85,247,0.25),transparent_60%),radial-gradient(circle_at_80%_70%,rgba(34,211,238,0.2),transparent_55%)]" />
        <div className="relative mx-auto max-w-7xl px-4 md:px-8 py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-300 text-xs font-semibold mb-5">
              <Sparkles className="w-3.5 h-3.5" /> Setup gamer com até 40% OFF
            </div>
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight">
              <span className="bg-gradient-to-r from-purple-400 via-cyan-300 to-purple-400 bg-clip-text text-transparent">
                TechStore
              </span>
              <br />
              <span className="text-slate-100">Sua Loja Gamer</span>
            </h1>
            <p className="mt-5 text-slate-400 text-lg max-w-lg">
              Notebooks, PCs gamer, periféricos e a melhor tecnologia para o seu setup.
            </p>

            <form
              onSubmit={(e) => { e.preventDefault(); window.location.href = `/products?q=${encodeURIComponent(q)}`; }}
              className="mt-7 flex items-center gap-2 max-w-md bg-slate-900/70 border border-purple-900/50 rounded-xl p-1.5 focus-within:border-cyan-400/60 transition"
            >
              <Search className="w-5 h-5 text-slate-500 ml-2" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar produtos..."
                className="flex-1 bg-transparent outline-none text-sm text-slate-100 placeholder:text-slate-500"
              />
              <button className="px-4 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-cyan-500 text-white text-sm font-semibold active:scale-95 transition">
                Buscar
              </button>
            </form>

            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                to="/products"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-semibold shadow-lg hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] active:scale-95 transition-all"
              >
                Ver Produtos <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/cart"
                className="inline-flex items-center px-6 py-3 rounded-xl border border-purple-500/50 text-slate-200 font-semibold hover:bg-purple-600/10 transition-all"
              >
                Ver Carrinho
              </Link>
            </div>
          </div>

          <div className="relative hidden md:block">
            <div className="aspect-square rounded-3xl bg-gradient-to-br from-purple-700/30 via-slate-900 to-cyan-500/20 border border-purple-900/40 p-10 shadow-[0_0_60px_rgba(168,85,247,0.3)]">
              <div className="grid grid-cols-2 gap-4 h-full">
                {featured.slice(0, 4).map((p) => {
                  const Icon = p.icon;
                  return (
                    <div key={p.id} className="rounded-2xl bg-slate-950/60 border border-purple-900/40 grid place-items-center">
                      <Icon className="w-14 h-14 text-cyan-300" strokeWidth={1.2} />
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured */}
      <section className="mx-auto max-w-7xl px-4 md:px-8 py-16">
        <div className="flex items-end justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-slate-100">Produtos em destaque</h2>
            <p className="text-slate-400 mt-1">Selecionados para elevar seu setup</p>
          </div>
          <Link to="/products" className="text-sm text-cyan-300 hover:text-cyan-200 font-semibold inline-flex items-center gap-1">
            Ver tudo <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
        <div className="grid gap-5 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
          {featured.map((p) => <ProductCard key={p.id} product={p} />)}
        </div>
      </section>
    </Layout>
  );
};

export default Home;
