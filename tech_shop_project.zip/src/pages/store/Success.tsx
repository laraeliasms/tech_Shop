import { Link, Navigate, useLocation } from "react-router-dom";
import { CheckCircle2, Home } from "lucide-react";
import Layout from "@/components/store/Layout";
import { formatBRL, CartItem } from "@/context/CartContext";

type OrderState = { id: number; items: CartItem[]; total: number; customer: string; email: string };

const Success = () => {
  const loc = useLocation() as { state?: OrderState };
  if (!loc.state) return <Navigate to="/" replace />;
  const { id, items, total, customer, email } = loc.state;

  return (
    <Layout>
      <section className="mx-auto max-w-2xl px-4 md:px-8 py-16">
        <div className="rounded-2xl bg-slate-900/60 border border-purple-900/40 p-8 text-center shadow-[0_0_40px_rgba(34,211,238,0.15)]">
          <div className="w-16 h-16 mx-auto rounded-full bg-cyan-400/20 grid place-items-center mb-4">
            <CheckCircle2 className="w-10 h-10 text-cyan-300" />
          </div>
          <h1 className="text-3xl font-bold text-slate-100">Compra aprovada!</h1>
          <p className="text-slate-400 mt-2">Obrigado, {customer}. Um e-mail foi enviado para {email}.</p>
          <p className="mt-4 inline-block px-4 py-1.5 rounded-full bg-purple-600/20 border border-purple-500/40 text-purple-300 text-sm font-semibold">
            Pedido #{id}
          </p>
        </div>

        <div className="mt-6 rounded-2xl bg-slate-900/60 border border-purple-900/40 p-6">
          <h3 className="font-bold text-slate-100 mb-4">Resumo da compra</h3>
          <div className="space-y-2">
            {items.map((i) => (
              <div key={i.id} className="flex justify-between text-sm">
                <span className="text-slate-300">{i.quantity}x {i.name}</span>
                <span className="text-slate-400">{formatBRL(i.price * i.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-purple-900/40 mt-4 pt-4 flex justify-between text-lg font-bold">
            <span>Total pago</span><span className="text-cyan-300">{formatBRL(total)}</span>
          </div>
        </div>

        <div className="mt-6 text-center">
          <Link to="/" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-cyan-500 text-white font-semibold shadow-lg hover:shadow-[0_0_25px_rgba(168,85,247,0.5)] active:scale-95 transition-all">
            <Home className="w-4 h-4" /> Voltar para Home
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Success;
