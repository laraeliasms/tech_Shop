import { useMemo, useState } from "react";
import { toast } from "sonner";
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  Pencil,
  Check,
  Star,
  Laptop,
  Mouse,
  Keyboard,
  Monitor,
  Headphones,
  Smartphone,
  Camera,
  Tablet,
} from "lucide-react";

type Product = {
  id: string;
  code: string;
  name: string;
  price: number;
  rating: number;
  stock: number;
  Icon: React.ComponentType<{ className?: string }>;
};

type CartItem = { id: string; qty: number };

const INITIAL_PRODUCTS: Product[] = [
  { id: "1", code: "LP-001", name: "Laptop Pro 14\"", price: 1899.0, rating: 4.9, stock: 5, Icon: Laptop },
  { id: "2", code: "MS-204", name: "Mouse Ergonómico Wireless", price: 79.9, rating: 4.6, stock: 12, Icon: Mouse },
  { id: "3", code: "KB-310", name: "Teclado Mecânico RGB", price: 159.0, rating: 4.8, stock: 2, Icon: Keyboard },
  { id: "4", code: "MN-427", name: "Monitor 27\" 4K", price: 649.0, rating: 4.7, stock: 0, Icon: Monitor },
  { id: "5", code: "HP-512", name: "Auscultadores ANC", price: 249.0, rating: 4.8, stock: 8, Icon: Headphones },
  { id: "6", code: "SP-630", name: "Smartphone Ultra", price: 1199.0, rating: 4.9, stock: 3, Icon: Smartphone },
  { id: "7", code: "CM-741", name: "Câmara Mirrorless", price: 1499.0, rating: 4.7, stock: 1, Icon: Camera },
  { id: "8", code: "TB-852", name: "Tablet Pro 11\"", price: 899.0, rating: 4.8, stock: 6, Icon: Tablet },
];

const formatPrice = (v: number) =>
  new Intl.NumberFormat("pt-PT", { style: "currency", currency: "EUR" }).format(v);

function StockBadge({ stock }: { stock: number }) {
  if (stock === 0)
    return (
      <span className="inline-flex items-center rounded-full bg-red-50 px-2.5 py-1 text-xs font-medium text-red-700 ring-1 ring-inset ring-red-200">
        Esgotado
      </span>
    );
  if (stock <= 3)
    return (
      <span className="inline-flex items-center rounded-full bg-orange-50 px-2.5 py-1 text-xs font-medium text-orange-700 ring-1 ring-inset ring-orange-200">
        Últimas {stock} unidades
      </span>
    );
  return (
    <span className="inline-flex items-center rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-200">
      {stock} unidades
    </span>
  );
}

export default function TechStore() {
  const [storeName, setStoreName] = useState("Nimbus Tech");
  const [editingName, setEditingName] = useState(false);
  const [draftName, setDraftName] = useState(storeName);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);

  const cartDetailed = useMemo(
    () =>
      cart
        .map((i) => {
          const p = products.find((p) => p.id === i.id);
          return p ? { ...p, qty: i.qty, lineTotal: p.price * i.qty } : null;
        })
        .filter(Boolean) as (Product & { qty: number; lineTotal: number })[],
    [cart, products],
  );

  const subtotal = cartDetailed.reduce((s, i) => s + i.lineTotal, 0);

  const saveName = () => {
    const trimmed = draftName.trim();
    if (!trimmed) {
      toast.error("O nome da loja não pode ficar vazio");
      return;
    }
    setStoreName(trimmed);
    setEditingName(false);
    toast.success("Nome da loja alterado", { description: `Agora chama-se "${trimmed}"` });
  };

  const addToCart = (p: Product) => {
    const inCart = cart.find((c) => c.id === p.id)?.qty ?? 0;
    if (inCart + 1 > p.stock) {
      toast.error("Sem stock disponível", {
        description: `Apenas ${p.stock} unidade(s) de ${p.name} em stock.`,
      });
      return;
    }
    setCart((prev) => {
      const existing = prev.find((c) => c.id === p.id);
      if (existing) return prev.map((c) => (c.id === p.id ? { ...c, qty: c.qty + 1 } : c));
      return [...prev, { id: p.id, qty: 1 }];
    });
    toast.success("Produto adicionado", { description: p.name });
  };

  const incQty = (id: string) => {
    const p = products.find((p) => p.id === id);
    const inCart = cart.find((c) => c.id === id)?.qty ?? 0;
    if (!p || inCart + 1 > p.stock) {
      toast.error("Sem stock disponível");
      return;
    }
    setCart((prev) => prev.map((c) => (c.id === id ? { ...c, qty: c.qty + 1 } : c)));
  };

  const decQty = (id: string) => {
    setCart((prev) =>
      prev
        .map((c) => (c.id === id ? { ...c, qty: c.qty - 1 } : c))
        .filter((c) => c.qty > 0),
    );
  };

  const clearCart = () => {
    if (cart.length === 0) return;
    setCart([]);
    toast("Carrinho esvaziado");
  };

  const checkout = () => {
    if (cart.length === 0) {
      toast.error("O carrinho está vazio");
      return;
    }
    setProducts((prev) =>
      prev.map((p) => {
        const item = cart.find((c) => c.id === p.id);
        return item ? { ...p, stock: p.stock - item.qty } : p;
      }),
    );
    toast.success("Compra efetuada", {
      description: `Total: ${formatPrice(subtotal)} • Obrigado pela preferência!`,
    });
    setCart([]);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-slate-50/70 backdrop-blur-xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-indigo-600 text-white shadow-sm">
              <Laptop className="h-5 w-5" />
            </div>
            {editingName ? (
              <div className="flex items-center gap-2">
                <input
                  autoFocus
                  value={draftName}
                  onChange={(e) => setDraftName(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") saveName();
                    if (e.key === "Escape") {
                      setDraftName(storeName);
                      setEditingName(false);
                    }
                  }}
                  className="w-48 rounded-lg border border-slate-300 bg-white px-2 py-1 text-lg font-semibold text-slate-900 outline-none ring-indigo-500/40 focus:ring-2 sm:w-64"
                />
                <button
                  onClick={saveName}
                  className="grid h-8 w-8 place-items-center rounded-lg bg-indigo-600 text-white transition hover:bg-indigo-500 active:scale-95"
                  aria-label="Guardar nome"
                >
                  <Check className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5">
                <h1 className="text-lg font-semibold tracking-tight text-slate-900 sm:text-xl">
                  {storeName}
                </h1>
                <button
                  onClick={() => {
                    setDraftName(storeName);
                    setEditingName(true);
                  }}
                  className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 transition hover:bg-slate-200/70 hover:text-indigo-600 active:scale-95"
                  aria-label="Editar nome da loja"
                >
                  <Pencil className="h-4 w-4" />
                </button>
              </div>
            )}
          </div>

          <a
            href="#cart"
            className="relative inline-flex items-center gap-2 rounded-xl bg-slate-900 px-4 py-2 text-sm font-medium text-white shadow-sm transition hover:bg-slate-800 active:scale-95"
          >
            <ShoppingCart className="h-4 w-4" />
            <span className="hidden sm:inline">Carrinho</span>
            {cartCount > 0 && (
              <span className="absolute -right-2 -top-2 grid h-5 min-w-[20px] place-items-center rounded-full bg-indigo-600 px-1.5 text-[11px] font-semibold text-white ring-2 ring-slate-50">
                {cartCount}
              </span>
            )}
          </a>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="mb-8">
          <p className="text-sm font-medium uppercase tracking-wider text-indigo-600">Catálogo</p>
          <h2 className="mt-1 text-3xl font-semibold tracking-tight text-slate-900 sm:text-4xl">
            Tecnologia para criar sem limites
          </h2>
          <p className="mt-2 max-w-2xl text-slate-600">
            Seleção curada de hardware premium, com entrega rápida e garantia estendida.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
          {/* Products grid */}
          <section className="lg:col-span-2">
            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {products.map((p) => {
                const Icon = p.Icon;
                const disabled = p.stock === 0;
                return (
                  <article
                    key={p.id}
                    className="group flex flex-col rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md"
                  >
                    <div className="mb-4 grid h-28 place-items-center rounded-xl bg-gradient-to-br from-slate-100 to-slate-50">
                      <Icon className="h-12 w-12 text-slate-700 transition group-hover:scale-110 group-hover:text-indigo-600" />
                    </div>
                    <div className="mb-1 flex items-center justify-between">
                      <span className="text-xs font-medium text-slate-500">#{p.code}</span>
                      <span className="inline-flex items-center gap-1 text-xs font-medium text-amber-600">
                        <Star className="h-3.5 w-3.5 fill-amber-500 text-amber-500" />
                        {p.rating.toFixed(1)}
                      </span>
                    </div>
                    <h3 className="text-base font-semibold text-slate-900">{p.name}</h3>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-xl font-semibold tracking-tight text-slate-900">
                        {formatPrice(p.price)}
                      </span>
                      <StockBadge stock={p.stock} />
                    </div>
                    <button
                      onClick={() => addToCart(p)}
                      disabled={disabled}
                      className="mt-5 inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-500 active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
                    >
                      <Plus className="h-4 w-4" />
                      Adicionar ao Carrinho
                    </button>
                  </article>
                );
              })}
            </div>
          </section>

          {/* Cart side panel */}
          <aside id="cart" className="lg:col-span-1">
            <div className="sticky top-24 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5 text-indigo-600" />
                  <h3 className="text-lg font-semibold text-slate-900">O seu pedido</h3>
                </div>
                <button
                  onClick={clearCart}
                  className="inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-slate-500 transition hover:bg-slate-100 hover:text-red-600 active:scale-95"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Esvaziar
                </button>
              </div>

              {cartDetailed.length === 0 ? (
                <div className="rounded-xl border border-dashed border-slate-200 py-10 text-center">
                  <ShoppingCart className="mx-auto mb-2 h-8 w-8 text-slate-300" />
                  <p className="text-sm text-slate-500">O seu carrinho está vazio</p>
                </div>
              ) : (
                <ul className="divide-y divide-slate-100">
                  {cartDetailed.map((i) => {
                    const Icon = i.Icon;
                    return (
                      <li key={i.id} className="flex gap-3 py-3">
                        <div className="grid h-12 w-12 shrink-0 place-items-center rounded-lg bg-slate-100">
                          <Icon className="h-5 w-5 text-slate-700" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-slate-900">{i.name}</p>
                          <p className="text-xs text-slate-500">{formatPrice(i.price)} cada</p>
                          <div className="mt-2 flex items-center justify-between">
                            <div className="inline-flex items-center rounded-lg border border-slate-200 bg-slate-50">
                              <button
                                onClick={() => decQty(i.id)}
                                className="grid h-7 w-7 place-items-center rounded-l-lg text-slate-600 transition hover:bg-slate-200 active:scale-95"
                                aria-label="Diminuir"
                              >
                                <Minus className="h-3.5 w-3.5" />
                              </button>
                              <span className="w-7 text-center text-sm font-semibold text-slate-900">
                                {i.qty}
                              </span>
                              <button
                                onClick={() => incQty(i.id)}
                                className="grid h-7 w-7 place-items-center rounded-r-lg text-slate-600 transition hover:bg-slate-200 active:scale-95"
                                aria-label="Aumentar"
                              >
                                <Plus className="h-3.5 w-3.5" />
                              </button>
                            </div>
                            <span className="text-sm font-semibold text-slate-900">
                              {formatPrice(i.lineTotal)}
                            </span>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}

              <div className="mt-5 space-y-2 border-t border-slate-100 pt-4 text-sm">
                <div className="flex justify-between text-slate-600">
                  <span>Subtotal</span>
                  <span className="font-medium text-slate-900">{formatPrice(subtotal)}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Portes</span>
                  <span className="font-medium text-emerald-600">Grátis</span>
                </div>
                <div className="flex justify-between border-t border-slate-100 pt-3 text-base">
                  <span className="font-semibold text-slate-900">Total</span>
                  <span className="text-lg font-semibold tracking-tight text-slate-900">
                    {formatPrice(subtotal)}
                  </span>
                </div>
              </div>

              <button
                onClick={checkout}
                disabled={cart.length === 0}
                className="mt-5 w-full rounded-xl bg-indigo-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-indigo-500 active:scale-[0.98] disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
              >
                Finalizar Pedido Simulado
              </button>
            </div>
          </aside>
        </div>
      </main>

      <footer className="mx-auto max-w-7xl px-4 py-10 text-center text-xs text-slate-400 sm:px-6 lg:px-8">
        © {new Date().getFullYear()} {storeName}. Demonstração técnica.
      </footer>
    </div>
  );
}
