import { createContext, useContext, useMemo, useState, ReactNode } from "react";
import { Product } from "@/data/products";
import { toast } from "sonner";

export type CartItem = Product & { quantity: number };

type CartContextType = {
  items: CartItem[];
  add: (p: Product) => void;
  remove: (id: number) => void;
  updateQty: (id: number, qty: number) => void;
  clear: () => void;
  totalItems: number;
  subtotal: number;
};

const CartContext = createContext<CartContextType | null>(null);

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([]);

  const add = (p: Product) => {
    setItems((prev) => {
      const ex = prev.find((i) => i.id === p.id);
      if (ex) return prev.map((i) => (i.id === p.id ? { ...i, quantity: i.quantity + 1 } : i));
      return [...prev, { ...p, quantity: 1 }];
    });
    toast.success(`${p.name} adicionado ao carrinho`);
  };

  const remove = (id: number) => setItems((p) => p.filter((i) => i.id !== id));
  const updateQty = (id: number, qty: number) =>
    setItems((p) => p.map((i) => (i.id === id ? { ...i, quantity: Math.max(1, qty) } : i)));
  const clear = () => setItems([]);

  const { totalItems, subtotal } = useMemo(
    () => ({
      totalItems: items.reduce((a, b) => a + b.quantity, 0),
      subtotal: items.reduce((a, b) => a + b.price * b.quantity, 0),
    }),
    [items]
  );

  return (
    <CartContext.Provider value={{ items, add, remove, updateQty, clear, totalItems, subtotal }}>
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
};

export const formatBRL = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
