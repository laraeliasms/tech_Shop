import { Laptop, Monitor, Smartphone, Keyboard, Mouse, Headphones, Cpu, Watch, Gamepad2, Armchair, LucideIcon } from "lucide-react";

export type Product = {
  id: number;
  name: string;
  price: number;
  category: string;
  description: string;
  icon: LucideIcon;
  stock: number;
};

export const categories = [
  "Todos",
  "Notebook",
  "PC Gamer",
  "Smartphone",
  "Teclado",
  "Headset",
  "Monitor",
  "Mouse",
  "Cadeira",
  "Smartwatch",
  "Placa de Vídeo",
];

export const products: Product[] = [
  { id: 1, name: "Notebook Gamer RTX 4070", price: 8999.9, category: "Notebook", description: "Notebook gamer de alta performance com RTX 4070, 32GB RAM e SSD 1TB.", icon: Laptop, stock: 8 },
  { id: 2, name: "PC Gamer Ultra i9", price: 14999.0, category: "PC Gamer", description: "Setup completo com Intel i9, 64GB RAM, RTX 4080 e refrigeração líquida.", icon: Cpu, stock: 5 },
  { id: 3, name: "Smartphone Pro 5G", price: 4599.0, category: "Smartphone", description: "Smartphone topo de linha com câmera 200MP, 5G e tela AMOLED 120Hz.", icon: Smartphone, stock: 20 },
  { id: 4, name: "Teclado Mecânico RGB", price: 749.9, category: "Teclado", description: "Switches blue, iluminação RGB por tecla e estrutura em alumínio.", icon: Keyboard, stock: 30 },
  { id: 5, name: "Headset Surround 7.1", price: 599.0, category: "Headset", description: "Áudio surround 7.1, microfone com cancelamento de ruído e RGB.", icon: Headphones, stock: 25 },
  { id: 6, name: "Monitor UltraWide 34''", price: 3299.0, category: "Monitor", description: "Monitor curvo 34'', 165Hz, 1ms e resolução QHD.", icon: Monitor, stock: 12 },
  { id: 7, name: "Mouse Gamer Pro 26K", price: 449.0, category: "Mouse", description: "Sensor 26.000 DPI, 8 botões programáveis e iluminação RGB.", icon: Mouse, stock: 40 },
  { id: 8, name: "Cadeira Gamer Elite", price: 1999.0, category: "Cadeira", description: "Cadeira ergonômica reclinável com apoio lombar e braços 4D.", icon: Armchair, stock: 10 },
  { id: 9, name: "Smartwatch Sport X", price: 1299.0, category: "Smartwatch", description: "Monitoramento de saúde, GPS, resistente a água e bateria de 14 dias.", icon: Watch, stock: 18 },
  { id: 10, name: "Placa de Vídeo RTX 4080", price: 9499.0, category: "Placa de Vídeo", description: "16GB GDDR6X, ray tracing e DLSS 3 para o máximo de FPS.", icon: Gamepad2, stock: 6 },
];
